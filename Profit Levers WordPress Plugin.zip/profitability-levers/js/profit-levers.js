jQuery(function($){
    var chart = new Chart(document.getElementById('chart_container'), {
        type: 'bar',
        data: {
        labels: ['Baseline Net Profit', 'Recast Net Profit'],
        datasets: [{
            label: 'Net Profit : Baseline VS Recast',
            data: [0,0],
            backgroundColor: [
                '#003594',
                '#E8782c',
            ],
            borderColor: [
                'rgb(54, 162, 235)',
                'rgb(255, 159, 64)',
            ],
            borderWidth: 1,
        }]
        },
        options: {
            plugins : {
                legend : {
                    display : false
                },
            },
            animate : false,
            scales: {
            y: {
                beginAtZero: true
            }
        }
        }
    });

    $('#profit_levers').calx({
        data : profitLeversData,
        onAfterCalculate : function() {
            chart.data.datasets[0].data = [
                this.cells['C16'].getValue(),
                this.cells['Q16'].getValue(),
            ];

            chart.update();
        }
    })
});