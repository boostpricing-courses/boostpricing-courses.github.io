<div class="container">
    <div class="row profit_levers_box mb-5">
        <div class="col-md-12">
            <h1 class="text-center profit_levers_header">Profitability Levers</h1>
        </div>

        <form action="" id="profit_levers">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="d-block bg-light mb-0 p-2 text-center" style="height: 50px;" for="price_change">Price Change</label>
                            <input class="fw-bold form-control text-secondary text-center" id="price_change" onfocus="this.select()" tabindex="4" data-cell="E9" />
                        </div>
                        <div class="col-md-3">
                            <label class="d-block bg-light mb-0 p-2 text-center" style="height: 50px;" for="volume_change">Volume Change</label>
                            <input class="fw-bold form-control text-secondary text-center" id="volume_change" onfocus="this.select()" tabindex="5" data-cell="H9" />
                        </div>
                        <div class="col-md-3">
                            <label class="d-block bg-light mb-0 p-2 text-center" style="height: 50px;" for="cogs_change">COGS Change</label>
                            <input class="fw-bold form-control text-secondary text-center" id="cogs_change" onfocus="this.select()" tabindex="6" data-cell="K9" />
                        </div>
                        <div class="col-md-3">
                            <label class="d-block bg-light mb-0 p-2 text-center" style="height: 50px;" for="overhead_cost_change">Overhead Cost Change</label>
                            <input class="fw-bold form-control text-secondary text-center" id="overhead_cost_change" onfocus="this.select()" tabindex="7" data-cell="N9" />
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="d-block bg-light mb-0 p-2 text-center" style="height: 50px;" for="">Cumulative Change in Net Profit</label>
                    <div class="fw-bold text-center" style="font-size : 20px" data-cell="Q9"></div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-3">
                    <div class="row mb-3">
                        <label for="" class="fw-bold text-center col-sm-6">Metric</label>
                        <label for="" class="fw-bold text-center col-sm-6">Baseline</label>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="revenue" class="text-normal col-sm-6">Revenue</label>
                        <div class="col-sm-6">
                            <input id="revenue" type="text" class="form-control form-control-sm input-sm" onfocus="this.select()" tabindex="1" data-cell="C12">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="cogs" class="text-normal col-sm-6">- COGS</label>
                        <div class="col-sm-6">
                            <input id="cogs" type="text" class="form-control form-control-sm input-sm" onfocus="this.select()" tabindex="2" data-cell="C13">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="gross_margin" class="text-normal col-sm-6">Gross Margin</label>
                        <div class="col-sm-6">
                            <input id="gross_margin" type="text" class="form-control form-control-sm input-sm" disabled data-cell="C14">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="overhead_cost" class="text-normal col-sm-6">- Overhead Costs</label>
                        <div class="col-sm-6">
                            <input id="overhead_cost" type="text" class="form-control form-control-sm input-sm" onfocus="this.select()" tabindex="3" data-cell="C15">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="" class="text-normal col-sm-6">Net Profit</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm fw-bold" style="font-weight: bold" disabled data-cell="C16">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="" class="text-normal col-sm-6">Total COGS %</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="C18">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="" class="text-normal col-sm-6">GM %</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="C19">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="" class="text-normal col-sm-6">Overhead %</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="C20">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <label for="" class="text-normal col-sm-6">Net Profit %</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="C21">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 chart_container">
                    <canvas id="chart_container" height="200px"></canvas>
                </div>
                <div class="col-md-3">
                    <div class="row mb-3">
                        <label for="" class="fw-bold text-center col-md-6">Recast</label>
                        <label for="" class="fw-bold text-center col-md-6">% Variance</label>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q12">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R12">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q13">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R13">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q14">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R14">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q15">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R15">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm fw-bold" disabled data-cell="Q16">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm fw-bold" disabled data-cell="R16">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q18">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R18">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q19">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R19">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q20">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R20">
                        </div>
                    </div>

                    <div class="form-group row mb-2">
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="Q21">
                        </div>

                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-sm input-sm" disabled data-cell="R21">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>