<?php

/**
 * Plugin Name: Profitability Levers Calculator
 * Plugin URI: http://www.xsanisty.com/contact
 * Description: Profitability Levers Calculator - built for https://boostpricing.com
 * Version: 1.0.2
 * Author: Boost Pricing
 * Author URI: https://www.boostpricing.com
 * License: Propietary
 *
 * Changelog
 *      1.0.0   Initial Version
 *      1.0.1   Update styling
 *      1.0.2   Update styling to match existing design
 */

$profitLevelPath   = plugin_dir_path(__FILE__);
$profitLevelUrl    = plugins_url() . '/profitability-levers/';

/** Asset registry */
wp_register_script(
    'profit-levers',
    $profitLevelUrl . 'js/profit-levers.js',
    array(),
    '1.0',
    true
);

wp_register_script(
    'profit-levers-data',
    $profitLevelUrl . 'js/profit_levers_data.js',
    array(),
    '1.0',
    true
);

wp_register_script(
    'profit-levers-chart',
    'https://cdn.jsdelivr.net/npm/chart.js@4.2.1/dist/chart.umd.min.js',
    array(),
    '4.2.1',
    true
);

wp_register_script(
    'profit-levers-calx',
    $profitLevelUrl . 'libs/calx/jquery-calx-2.2.8.min.js',
    array(),
    '2.2.8',
    true
);

wp_register_script(
    'profit-levers-numeral',
    $profitLevelUrl . 'libs/calx/numeral.min.js',
    array(),
    '2.0.6',
    true
);

wp_register_style(
    'profit-levers-css',
    $profitLevelUrl . 'css/profit-levers.css',
    array(),
    '1.0.2',
    false
);


/** Short code registry */
add_shortcode(
    'profit_levers',
    function () use ($profitLevelPath) {
        wp_enqueue_script('profit-levers-data');
        wp_enqueue_script('profit-levers-numeral');
        wp_enqueue_script('profit-levers-chart');
        wp_enqueue_script('profit-levers-calx');
        wp_enqueue_script('profit-levers');

        wp_enqueue_style('profit-levers-css');

        ob_start();
        require $profitLevelPath . 'template/profit-levers.php';

        return ob_get_clean();
    }
);


add_shortcode(
    'profit_levers_bootstrap',
    function () {
        wp_register_style(
            'profit-level-bootstrap',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css',
            array(),
            '3.3.6',
            false
        );
        wp_enqueue_style('profit-level-bootstrap');
    }
);
